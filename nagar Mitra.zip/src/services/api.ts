import {
  AIVerificationResponse,
  CivicComplaint,
  ComplaintCategory,
  ComplaintSeverity,
  ComplaintStatus,
  ComplaintSubmissionPayload,
  DashboardStats,
  Department,
  LocationData,
} from '../types/api';
import { INITIAL_COMPLAINTS, INITIAL_DASHBOARD_STATS } from '../data/demoComplaints';

const API_BASE_URL =
  (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_API_BASE_URL) ||
  'http://localhost:8000';
const STORAGE_KEY_COMPLAINTS = 'smart_civic_ai_complaints_v1';
const STORAGE_KEY_STATS = 'smart_civic_ai_stats_v1';

// Initialize localStorage with demo data if empty
function getStoredComplaints(): CivicComplaint[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_COMPLAINTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_COMPLAINTS, JSON.stringify(INITIAL_COMPLAINTS));
      return INITIAL_COMPLAINTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_COMPLAINTS;
  }
}

function saveComplaints(complaints: CivicComplaint[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_COMPLAINTS, JSON.stringify(complaints));
  } catch (e) {
    console.warn('LocalStorage save failed:', e);
  }
}

function getStoredStats(): DashboardStats {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_STATS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_STATS, JSON.stringify(INITIAL_DASHBOARD_STATS));
      return INITIAL_DASHBOARD_STATS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_DASHBOARD_STATS;
  }
}

/**
 * Determine recommended department and initial severity based on category and description keywords
 */
function getDepartmentForCategory(category: ComplaintCategory): Department {
  switch (category) {
    case 'Road Damage':
      return 'Roads Department';
    case 'Waste Management':
      return 'Sanitation & Waste';
    case 'Water Leakage':
    case 'Drainage':
      return 'Water Works & Sewerage';
    case 'Streetlight':
      return 'Electrical & Lighting';
    case 'Traffic & Safety':
      return 'Traffic Management';
    case 'Public Infrastructure':
      return 'Public Works Department';
    default:
      return 'Urban Planning';
  }
}

/**
 * Simulates multi-modal AI verification heuristics for the hackathon demo
 * (or handles real backend API if VITE_API_BASE_URL is reachable)
 */
export async function verifyComplaint(
  payload: ComplaintSubmissionPayload,
  options?: { simulateMismatch?: boolean; simulateDuplicate?: boolean; simulateFarLocation?: boolean }
): Promise<AIVerificationResponse> {
  // Attempt real API if available
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 1200);

    const formData = new FormData();
    formData.append('description', payload.description);
    formData.append('category', payload.category);
    formData.append('location', JSON.stringify(payload.location));
    if (payload.imageFile) {
      formData.append('image', payload.imageFile);
    }

    const response = await fetch(`${API_BASE_URL}/api/complaints/verify`, {
      method: 'POST',
      body: formData,
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (response.ok) {
      const data = await response.json();
      return data as AIVerificationResponse;
    }
  } catch {
    // Gracefully fallback to high-fidelity client simulation
  }

  // Realistic AI simulation pipeline delay (approx 1.5 - 2s)
  await new Promise((resolve) => setTimeout(resolve, 1800));

  const text = payload.description.toLowerCase();
  const category = payload.category;
  const isUrgentWord = text.includes('burst') || text.includes('emergency') || text.includes('hazard') || text.includes('accident') || text.includes('crater') || text.includes('danger') || text.includes('flood') || text.includes('deep');

  let severity: ComplaintSeverity = 'MEDIUM';
  let urgency = 65;

  if (category === 'Water Leakage' && text.includes('burst')) {
    severity = 'CRITICAL';
    urgency = 92;
  } else if (category === 'Traffic & Safety' || isUrgentWord) {
    severity = 'HIGH';
    urgency = 84;
  } else if (category === 'Road Damage') {
    severity = 'HIGH';
    urgency = 78;
  } else if (category === 'Public Infrastructure') {
    severity = 'LOW';
    urgency = 40;
  }

  const existingComplaints = getStoredComplaints();
  const randomId = `COMP-${String(existingComplaints.length + 1).padStart(5, '0')}`;

  // Handle demo simulation modes
  if (options?.simulateMismatch) {
    return {
      status: 'REJECTED',
      complaint_id: randomId,
      category: payload.category,
      severity: 'LOW',
      urgency_score: 25,
      summary: 'Image analysis detected a severe category mismatch. Visual evidence does not corroborate reported incident.',
      recommended_department: getDepartmentForCategory(payload.category),
      confidence_score: 94,
      created_at: new Date().toISOString(),
      image: {
        provided: true,
        validator: {
          relevant: false,
          match: false,
          issue_type: 'Unrelated Indoor / Object Image',
          confidence: 94,
          reason: 'Uploaded photo exhibits indoor household elements rather than outdoor civic infrastructure.',
        },
      },
      duplicate: {
        possible: false,
        score: 12,
      },
      location_validation: {
        valid: true,
        distance_meters: 15,
        reason: 'GPS telemetry in city zone, but rejected due to visual discrepancy.',
      },
    };
  }

  if (options?.simulateDuplicate) {
    return {
      status: 'NEEDS_REVIEW',
      complaint_id: randomId,
      category: payload.category,
      severity: severity,
      urgency_score: urgency,
      summary: 'Potential duplicate complaint identified within 80 meters reported in past 24 hours.',
      recommended_department: getDepartmentForCategory(payload.category),
      confidence_score: 91,
      created_at: new Date().toISOString(),
      image: {
        provided: true,
        validator: {
          relevant: true,
          match: true,
          issue_type: `${payload.category} Incident`,
          confidence: 91,
          reason: 'Uploaded imagery is consistent with reported issue.',
        },
      },
      duplicate: {
        possible: true,
        score: 78,
        matched_complaint_id: 'COMP-00012',
        matched_summary: 'Earlier report at same coordinate cluster regarding road asphalt defect.',
      },
      location_validation: {
        valid: true,
        distance_meters: 38,
        reason: 'GPS coordinates within cluster bounds of active municipal report.',
      },
    };
  }

  if (options?.simulateFarLocation) {
    return {
      status: 'NEEDS_REVIEW',
      complaint_id: randomId,
      category: payload.category,
      severity: severity,
      urgency_score: urgency,
      summary: 'Location distance mismatch. Report GPS is 1.4km away from declared municipal jurisdiction point.',
      recommended_department: getDepartmentForCategory(payload.category),
      confidence_score: 87,
      created_at: new Date().toISOString(),
      image: {
        provided: true,
        validator: {
          relevant: true,
          match: true,
          issue_type: `${payload.category} Incident`,
          confidence: 87,
          reason: 'Photo content matches issue description.',
        },
      },
      duplicate: {
        possible: false,
        score: 22,
      },
      location_validation: {
        valid: false,
        distance_meters: 1420,
        reason: 'Geolocation coordinate deviation exceeds municipal geofence tolerance.',
      },
    };
  }

  // Normal successful verification
  return {
    status: 'VERIFIED',
    complaint_id: randomId,
    category: payload.category,
    severity: severity,
    urgency_score: urgency,
    summary: `Verified ${payload.category} issue with valid visual telemetry, GPS proximity, and clean duplicate index.`,
    recommended_department: getDepartmentForCategory(payload.category),
    confidence_score: 95,
    created_at: new Date().toISOString(),
    image: {
      provided: true,
      validator: {
        relevant: true,
        match: true,
        issue_type: `${payload.category} Issue`,
        confidence: 95,
        reason: 'The uploaded image strongly supports the reported civic issue with clear structural indicators.',
      },
    },
    duplicate: {
      possible: false,
      score: 19,
    },
    location_validation: {
      valid: true,
      distance_meters: 24,
      reason: 'Verified within 24m of public municipal right-of-way corridor.',
    },
  };
}

/**
 * Submit verified complaint to local store or backend REST API
 */
export async function submitComplaint(
  payload: ComplaintSubmissionPayload,
  aiResult: AIVerificationResponse
): Promise<CivicComplaint> {
  const newComplaint: CivicComplaint = {
    id: aiResult.complaint_id || `COMP-${String(Date.now()).slice(-5)}`,
    title: `${payload.category} - ${payload.location.address || 'Reported Incident'}`,
    description: payload.description,
    category: payload.category,
    imageUrl: payload.imageBase64 || (payload.imageFile ? URL.createObjectURL(payload.imageFile) : 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=800&q=80'),
    imageFileName: payload.imageFile?.name || 'evidence_capture.jpg',
    imageFileSize: payload.imageFile ? `${(payload.imageFile.size / (1024 * 1024)).toFixed(1)} MB` : '1.8 MB',
    location: payload.location,
    severity: aiResult.severity,
    urgency_score: aiResult.urgency_score,
    status: 'AI Verified',
    department: aiResult.recommended_department,
    ai_verification: aiResult,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    citizen_name: payload.citizen_name || 'Anonymous Citizen',
    citizen_contact: payload.citizen_contact || 'citizen@nagarmitra.local',
    timeline: [
      {
        id: `t-${Date.now()}-1`,
        title: 'Report Submitted',
        description: 'Citizen complaint with photo and GPS location submitted.',
        timestamp: new Date().toISOString(),
        type: 'creation',
        actor: payload.citizen_name || 'Citizen',
      },
      {
        id: `t-${Date.now()}-2`,
        title: 'AI Verification Passed',
        description: `Automated analysis completed: Confidence ${aiResult.confidence_score}%, Urgency ${aiResult.urgency_score}/100.`,
        timestamp: new Date().toISOString(),
        type: 'verification',
        actor: 'Nagar Mitra AI Engine v3.4',
      },
      {
        id: `t-${Date.now()}-3`,
        title: 'Auto-Routed to Department',
        description: `Transferred to ${aiResult.recommended_department} queue for task dispatch.`,
        timestamp: new Date().toISOString(),
        type: 'assignment',
        actor: 'Civic Dispatch Router',
      },
    ],
    internal_notes: [],
  };

  try {
    const response = await fetch(`${API_BASE_URL}/api/complaints`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newComplaint),
    });
    if (response.ok) {
      const data = await response.json();
      return data;
    }
  } catch {
    // fallback
  }

  const complaints = getStoredComplaints();
  const updated = [newComplaint, ...complaints];
  saveComplaints(updated);

  // Update stats
  const stats = getStoredStats();
  stats.total_complaints += 1;
  stats.ai_verified += 1;
  if (newComplaint.severity === 'CRITICAL') {
    stats.critical += 1;
  }
  stats.pending += 1;
  try {
    localStorage.setItem(STORAGE_KEY_STATS, JSON.stringify(stats));
  } catch {}

  return newComplaint;
}

/**
 * Fetch all complaints with optional filtering
 */
export async function getComplaints(filters?: {
  search?: string;
  category?: string;
  severity?: string;
  status?: string;
  department?: string;
}): Promise<CivicComplaint[]> {
  try {
    const url = new URL(`${API_BASE_URL}/api/complaints`);
    if (filters?.search) url.searchParams.append('search', filters.search);
    if (filters?.category) url.searchParams.append('category', filters.category);
    if (filters?.severity) url.searchParams.append('severity', filters.severity);
    if (filters?.status) url.searchParams.append('status', filters.status);
    if (filters?.department) url.searchParams.append('department', filters.department);

    const res = await fetch(url.toString());
    if (res.ok) {
      return await res.json();
    }
  } catch {
    // fallback
  }

  let list = getStoredComplaints();

  if (filters?.search) {
    const s = filters.search.toLowerCase();
    list = list.filter(
      (c) =>
        c.id.toLowerCase().includes(s) ||
        c.description.toLowerCase().includes(s) ||
        (c.title && c.title.toLowerCase().includes(s)) ||
        (c.location.address && c.location.address.toLowerCase().includes(s)) ||
        c.department.toLowerCase().includes(s)
    );
  }

  if (filters?.category && filters.category !== 'ALL') {
    list = list.filter((c) => c.category === filters.category);
  }

  if (filters?.severity && filters.severity !== 'ALL') {
    list = list.filter((c) => c.severity === filters.severity);
  }

  if (filters?.status && filters.status !== 'ALL') {
    list = list.filter((c) => c.status === filters.status);
  }

  if (filters?.department && filters.department !== 'ALL') {
    list = list.filter((c) => c.department === filters.department);
  }

  return list;
}

/**
 * Fetch complaint by ID
 */
export async function getComplaintById(id: string): Promise<CivicComplaint | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/api/complaints/${id}`);
    if (res.ok) {
      return await res.json();
    }
  } catch {
    // fallback
  }

  const list = getStoredComplaints();
  return list.find((c) => c.id === id) || null;
}

/**
 * Update complaint status, department assignment, or add internal staff note
 */
export async function updateComplaintStatus(
  id: string,
  updates: {
    status?: ComplaintStatus;
    department?: Department;
    note?: { author: string; role: string; content: string };
    actor?: string;
  }
): Promise<CivicComplaint | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/api/complaints/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (res.ok) {
      return await res.json();
    }
  } catch {
    // fallback
  }

  const list = getStoredComplaints();
  const index = list.findIndex((c) => c.id === id);
  if (index === -1) return null;

  const current = list[index];
  const updated = { ...current, updated_at: new Date().toISOString() };

  if (updates.status && updates.status !== current.status) {
    const oldStatus = current.status;
    updated.status = updates.status;
    updated.timeline.push({
      id: `t-${Date.now()}`,
      title: `Status Changed to ${updates.status}`,
      description: `Status updated from '${oldStatus}' to '${updates.status}' by municipal staff.`,
      timestamp: new Date().toISOString(),
      type: updates.status === 'Resolved' ? 'resolution' : 'status_change',
      actor: updates.actor || 'Operations Supervisor',
    });
  }

  if (updates.department && updates.department !== current.department) {
    const oldDept = current.department;
    updated.department = updates.department;
    updated.timeline.push({
      id: `t-${Date.now()}-dept`,
      title: `Re-assigned to ${updates.department}`,
      description: `Transferred jurisdiction from ${oldDept} to ${updates.department}.`,
      timestamp: new Date().toISOString(),
      type: 'assignment',
      actor: updates.actor || 'Operations Dispatcher',
    });
  }

  if (updates.note && updates.note.content.trim()) {
    const newNote = {
      id: `n-${Date.now()}`,
      author: updates.note.author,
      role: updates.note.role,
      content: updates.note.content.trim(),
      timestamp: new Date().toISOString(),
    };
    updated.internal_notes.push(newNote);
    updated.timeline.push({
      id: `t-${Date.now()}-note`,
      title: 'Internal Operational Note Added',
      description: `"${updates.note.content.slice(0, 70)}${updates.note.content.length > 70 ? '...' : ''}"`,
      timestamp: new Date().toISOString(),
      type: 'note',
      actor: `${updates.note.author} (${updates.note.role})`,
    });
  }

  list[index] = updated;
  saveComplaints(list);
  return updated;
}

/**
 * Get aggregated dashboard statistics
 */
export async function getDashboardStats(): Promise<DashboardStats> {
  try {
    const res = await fetch(`${API_BASE_URL}/api/dashboard/stats`);
    if (res.ok) {
      return await res.json();
    }
  } catch {
    // fallback
  }

  const complaints = getStoredComplaints();
  const stats = getStoredStats();

  const total = complaints.length >= 6 ? 1280 + complaints.length : complaints.length;
  const pending = complaints.filter((c) => c.status === 'Submitted' || c.status === 'Under Review').length;
  const verified = complaints.filter((c) => c.status === 'AI Verified' || c.status === 'In Progress').length;
  const critical = complaints.filter((c) => c.severity === 'CRITICAL' && c.status !== 'Resolved').length;
  const resolved = complaints.filter((c) => c.status === 'Resolved').length;

  return {
    total_complaints: total,
    pending: pending + 240,
    ai_verified: verified + 920,
    critical: critical + 30,
    resolved: resolved + 695,
    average_resolution_hours: stats.average_resolution_hours,
    ai_accuracy_rate: stats.ai_accuracy_rate,
  };
}
